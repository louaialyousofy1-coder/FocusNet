package com.focusnet

import android.app.*
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.VpnService
import android.os.*
import android.provider.Settings

/**
 * VPN محلي: كل التطبيقات ما عدا (التطبيق الأمامي + الاستثناءات) تُوجَّه إلى النفق
 * ولا نقرأ حزمها إطلاقاً، فتُسقط عملياً ويتوقف استهلاكها للإنترنت.
 */
class FocusVpnService : VpnService() {

    companion object {
        const val ACTION_STOP = "com.focusnet.STOP"
        @Volatile var running = false
        fun prefs(c: Context) = c.getSharedPreferences("focus", MODE_PRIVATE)
        fun exceptions(c: Context): Set<String> =
            prefs(c).getStringSet("ex", setOf("com.whatsapp", "com.google.android.dialer"))!!
    }

    private var tun: ParcelFileDescriptor? = null
    private var current = ""
    private val handler = Handler(Looper.getMainLooper())

    private val tick = object : Runnable {
        override fun run() {
            val fg = foregroundApp()
            if (fg != null && fg != current) { current = fg; rebuild() }
            handler.postDelayed(this, 1500)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { stopSelf(); return START_NOT_STICKY }
        startForegroundNotification()
        running = true
        handler.removeCallbacks(tick)
        handler.post(tick)
        return START_STICKY
    }

    private fun startForegroundNotification() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("focus", "FocusNet", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(this, 0,
            Intent(this, FocusVpnService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, "focus")
            .setSmallIcon(android.R.drawable.stat_sys_data_bluetooth)
            .setContentTitle("FocusNet يعمل")
            .setContentText("الإنترنت مخصص للتطبيق الحالي")
            .addAction(Notification.Action.Builder(null, "إيقاف", stop).build())
            .setOngoing(true).build()
        if (Build.VERSION.SDK_INT >= 29)
            startForeground(1, n, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SYSTEM_EXEMPTED)
        else startForeground(1, n)
    }

    @Suppress("DEPRECATION")
    private fun foregroundApp(): String? {
        val usm = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val now = System.currentTimeMillis()
        val ev = usm.queryEvents(now - 60 * 60 * 1000, now)
        val e = UsageEvents.Event()
        var last: String? = null
        while (ev.hasNextEvent()) {
            ev.getNextEvent(e)
            if (e.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND && e.packageName != packageName)
                last = e.packageName
        }
        return last
    }

    private fun keyboardPackage(): String? {
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD)
        return s?.let { ComponentName.unflattenFromString(it)?.packageName }
    }

    private fun rebuild() {
        val keep = HashSet(exceptions(this)).apply {
            add(current); add(packageName); keyboardPackage()?.let { add(it) }
        }
        val blocked = packageManager.getInstalledApplications(0)
            .map { it.packageName }.filter { it !in keep }

        val b = Builder().setSession("FocusNet")
            .addAddress("10.8.0.2", 32).addAddress("fd00::2", 128)
            .addRoute("0.0.0.0", 0).addRoute("::", 0)
        var added = 0
        for (p in blocked) {
            try { b.addAllowedApplication(p); added++ } catch (_: PackageManager.NameNotFoundException) {}
        }
        // حماية: إن لم يوجد تطبيق للحظر فلا نضيف شيئاً حتى لا يُوجَّه كل شيء للنفق
        if (added == 0) { try { b.addAllowedApplication(packageName) } catch (_: Exception) {} }

        val old = tun
        tun = b.establish()
        old?.close()
    }

    override fun onDestroy() {
        running = false
        handler.removeCallbacks(tick)
        tun?.close(); tun = null
        super.onDestroy()
    }

    override fun onRevoke() { stopSelf() }
}
