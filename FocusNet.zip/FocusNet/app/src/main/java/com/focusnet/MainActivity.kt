package com.focusnet

import android.Manifest
import android.app.Activity
import android.app.AppOpsManager
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.net.VpnService
import android.os.Bundle
import android.os.Process
import android.provider.Settings
import android.view.Gravity
import android.widget.*
import android.app.AlertDialog

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var toggle: Button

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(48, 48, 48, 48)
            layoutDirection = LinearLayout.LAYOUT_DIRECTION_RTL
        }
        val title = TextView(this).apply { text = "FocusNet"; textSize = 28f; gravity = Gravity.CENTER }
        val desc = TextView(this).apply {
            text = "يحجب الإنترنت عن تطبيقات الخلفية ويخصصه للتطبيق الذي تستخدمه الآن."
            gravity = Gravity.CENTER; setPadding(0, 24, 0, 48)
        }
        status = TextView(this).apply { gravity = Gravity.CENTER; setPadding(0, 0, 0, 32) }
        toggle = Button(this).apply { setOnClickListener { onToggle() } }
        val perm = Button(this).apply {
            text = "1) منح صلاحية الوصول للاستخدام"
            setOnClickListener { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }
        }
        val ex = Button(this).apply { text = "2) اختيار التطبيقات المستثناة"; setOnClickListener { pickExceptions() } }

        listOf(title, desc, status, perm, ex, toggle).forEach { root.addView(it) }
        setContentView(root)
        requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun refresh() {
        status.text = if (FocusVpnService.running) "الحالة: يعمل ✅" else "الحالة: متوقف"
        toggle.text = if (FocusVpnService.running) "إيقاف" else "3) تشغيل"
    }

    private fun hasUsageAccess(): Boolean {
        val ops = getSystemService(APP_OPS_SERVICE) as AppOpsManager
        @Suppress("DEPRECATION")
        return ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), packageName) ==
            AppOpsManager.MODE_ALLOWED
    }

    private fun onToggle() {
        if (FocusVpnService.running) {
            startService(Intent(this, FocusVpnService::class.java).setAction(FocusVpnService.ACTION_STOP))
            toggle.postDelayed({ refresh() }, 400)
            return
        }
        if (!hasUsageAccess()) {
            Toast.makeText(this, "امنح صلاحية الوصول للاستخدام أولاً", Toast.LENGTH_LONG).show()
            return
        }
        val i = VpnService.prepare(this)
        if (i != null) startActivityForResult(i, 100) else startVpn()
    }

    override fun onActivityResult(req: Int, res: Int, d: Intent?) {
        if (req == 100 && res == RESULT_OK) startVpn()
    }

    private fun startVpn() {
        startForegroundService(Intent(this, FocusVpnService::class.java))
        toggle.postDelayed({ refresh() }, 600)
    }

    private fun pickExceptions() {
        val apps = packageManager.getInstalledApplications(0)
            .filter { it.flags and ApplicationInfo.FLAG_SYSTEM == 0 && it.packageName != packageName }
            .sortedBy { packageManager.getApplicationLabel(it).toString() }
        val names = apps.map { packageManager.getApplicationLabel(it).toString() }.toTypedArray()
        val saved = FocusVpnService.exceptions(this)
        val checked = BooleanArray(apps.size) { apps[it].packageName in saved }
        AlertDialog.Builder(this)
            .setTitle("تطبيقات لا تُحجب أبداً")
            .setMultiChoiceItems(names, checked) { _, i, c -> checked[i] = c }
            .setPositiveButton("حفظ") { _, _ ->
                val set = apps.indices.filter { checked[it] }.map { apps[it].packageName }.toSet()
                FocusVpnService.prefs(this).edit().putStringSet("ex", set).apply()
            }.setNegativeButton("إلغاء", null).show()
    }
}
