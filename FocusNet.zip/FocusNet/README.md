# FocusNet
1. افتح المجلد في Android Studio (Koala أو أحدث) ودع Gradle يزامن.
2. شغّل على جهاز حقيقي (Android 8+).
3. امنح: صلاحية Usage Access ← اختر الاستثناءات ← اضغط تشغيل ← وافق على طلب VPN.
